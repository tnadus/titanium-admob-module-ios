/*
* Single Window Application Template:
* A basic starting point for your application.  Mostly a blank canvas.
*
* In app.js, we generally take care of a few things:
* - Bootstrap the application with any data we need
* - Check for dependencies like device type, platform version or network connection
* - Require and open our top-level UI component
*
*/

//bootstrap and check dependencies
if (Ti.version < 1.8) {
	alert('Sorry - this application template requires Titanium Mobile SDK 1.8 or later');
}

var admob = require('ti.admobmoduleios');

/* - Create window */
var win;
(function() {
	win = Ti.UI.createWindow({
		backgroundColor:'#00ff00',
	});

	win.open();
})();

var label = Ti.UI.createLabel({
	color : '#000000',
	backgroundColor : '#FFF',
	text : 'Show ad If it is ready',
	height : 'auto',
	width : 'auto'
});
win.add(label);

//create and load the request
function createAd() {
	return admob.createInterstitial({
		adUnitId : '<YOUR_AD_UNIT_ID>',
		testDevices : [admob.SIMULATOR_ID],
	});
}

var fullScreenAd = createAd();

fullScreenAd.loadAd();

admob.addEventListener('InterstitialDidReceiveAdNotification', function(e) {
	Titanium.API.info("InterstitialDidReceiveAdNotification");
});

admob.addEventListener(fullScreenAd.kInterstitialDidFailToReceiveAdNotification, function(e) {
	Titanium.API.info("InterstitialDidFailToReceiveAdNotification");
			setTimeout(function() {
			Ti.API.info('Timeout');
			fullScreenAd.loadAd();
		}, 3000);
});

admob.addEventListener('InterstitialDidDismissScreen', function(e) {
	Titanium.API.info("InterstitialDidDismissScreen");
	fullScreenAd = createAd();
	fullScreenAd.loadAd();
});

label.addEventListener('click', function(e) {
	Titanium.API.info("You clicked the button");
	var isReady = fullScreenAd.isReady();

	if (isReady) {
		fullScreenAd.show();
	} else {
		alert("Interstitial is NOT READY!");
	}
}); 


//create banner
var adBanner;
win.add(adBanner = admob.createView({
    top: Titanium.Platform.displayCaps.platformHeight - 50, left: 0,
    width: Titanium.Platform.displayCaps.platformWidth, height: 50,
    adUnitId: '<YOUR_AD_UNIT_ID>', // You can get your own at http: //www.admob.com/
    adBackgroundColor: 'black',
    // You can get your device's id for testDevices by looking in the console log after the app launched
    testDevices: [admob.SIMULATOR_ID],
    dateOfBirth: new Date(1985, 10, 1, 12, 1, 1),
    gender: 'male',
    keywords: ''
}));

adBanner.addEventListener('didReceiveAd', function() {
    //alert('Did receive ad!');
});
adBanner.addEventListener('didFailToReceiveAd', function() {
    //alert('Failed to receive ad!');
});
adBanner.addEventListener('willPresentScreen', function() {
    //alert('Presenting screen!');
});
adBanner.addEventListener('willDismissScreen', function() {
    //alert('Dismissing screen!');
});
adBanner.addEventListener('didDismissScreen', function() {
    //alert('Dismissed screen!');
});
adBanner.addEventListener('willLeaveApplication', function() {
    //alert('Leaving the app!');
});